﻿using SageFrame.Web;
using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.CostCenter;
using SageFrame.RestroOrder;


public partial class Modules_CostCenter_CostCenter : BaseUserControl
{
    public string UserName = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        IncludeJs("ROItem", "/js/uploadfile/form.js", "/js/uploadfile/jquery.uploadfile.js");
        //IncludeJs("ROItem", "/Modules/ROItem/Js/itemscript.js");
        UserName = GetUsername;
        BindGrid();
        if (!Page.IsPostBack)
        {
            BindDefaultPrinter();
            tbl1.Visible = false;
            clearText();
            ddlstores();
        }

    }

    private void ddlstores() {
        RestrOrderController roc = new RestrOrderController();
        ddlstore.DataSource = roc.getIssueToDDl();
        ddlstore.DataBind();
        ddlstore.Items.Insert(0, " --Select-- ");
    }
    private void BindDefaultPrinter()
    {
        List<string> printerList = new List<string>();
        foreach (string printer in System.Drawing.Printing.PrinterSettings.InstalledPrinters)
        {
            printerList.Add(printer);
        }
        ddlDefaultPrinter.DataSource = printerList;
        ddlDefaultPrinter.DataBind();

    }

    #region Event Control
    protected void btnadd_Click(object sender, EventArgs e)
    {
        tbl1.Visible = true;
        CostCenterName.ReadOnly = false;
    }

    protected void CostCenterSave_Click(object sender, EventArgs e)
    {
        CostCenterInfo dataObj = new CostCenterInfo();
        dataObj.CostCenterId = (String.IsNullOrEmpty(hdfcostcenterid.Value) == true) ? 0 : Convert.ToInt32(hdfcostcenterid.Value);
        dataObj.CostCenterName = CostCenterName.Text;
        dataObj.NumberOfCounter = Convert.ToInt32(NumberOfCounter.Text);
        dataObj.Username = UserName;
        dataObj.DefaultPrinter = ddlDefaultPrinter.SelectedValue;
        dataObj.coDiscount = txtCoDiscount.Text == "" ? 0 : Convert.ToDecimal(txtCoDiscount.Text);
        if (ddlstore.SelectedIndex == 0)
            dataObj.store = 0;
        else
            dataObj.store = Convert.ToInt32(ddlstore.Text);
        CostCenterController controller = new CostCenterController();
        controller.SaveCostCenter(dataObj);
        if (dataObj.CostCenterId == 0)
        {
            //ScriptManager.RegisterClientScriptBlock(this.GetType(),)
            Response.Write("<script>alert('Record saved successfully', 'Information!!', function () { $.alerts.dialogClass = null; });</script>");
            
        }
        else
        {

            Response.Write("<script>alert('Record updated successfully', 'Information!!', function () { $.alerts.dialogClass = null; });</script>");
        }
        BindGrid();
        tbl1.Visible = false;
        gdvCostCenter.Visible = true;
        clearText();
    }


    protected void gdvCostCenter_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        if (e.CommandName == "EditCostCenter")
        {
            //CostCenterName.ReadOnly = true;
            CostCenterInfo costCenterInfo = new CostCenterInfo();
            CostCenterController roc = new CostCenterController();
            LinkButton btn = (LinkButton)e.CommandSource;
            GridViewRow grdrow = ((GridViewRow)btn.NamingContainer);
            int index = Convert.ToInt32(gdvCostCenter.DataKeys[grdrow.RowIndex].Values["CostCenterId"].ToString());
            costCenterInfo = roc.GetCostCenterById(index);
            hdfcostcenterid.Value = costCenterInfo.CostCenterId.ToString();
            CostCenterName.Text = costCenterInfo.CostCenterName;
            if (costCenterInfo.store!=0)
                ddlstore.SelectedValue = costCenterInfo.store.ToString();
            //ddlstore.Text = costCenterInfo.store;
            //ddlDefaultPrinter.SelectedValue = costCenterInfo.DefaultPrinter;
            
            txtCoDiscount.Text = costCenterInfo.coDiscount.ToString();
            tbl1.Visible = true;
            gdvCostCenter.Visible = false;
        }
        else
            if (e.CommandName == "DeleteCostCenter")
            {

                LinkButton btn = (LinkButton)e.CommandSource;
                GridViewRow grdrow = ((GridViewRow)btn.NamingContainer);
                int empid = Convert.ToInt32(gdvCostCenter.DataKeys[grdrow.RowIndex].Values["CostCenterId"].ToString());
                CostCenterController con = new CostCenterController();
                con.deleteCostCenter(empid);

                Response.Write("<script>lert('Record deleted successfully', 'Information!!', function () { $.alerts.dialogClass = null; });</script>");
                BindGrid();
            }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        tbl1.Visible = false;
        gdvCostCenter.Visible = true;
        clearText();

    }

    protected void gdvCostCenter_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvCostCenter.PageIndex = e.NewPageIndex;
        BindGrid();
    }
    #endregion

    #region User Function
    private void BindGrid()
    {
        CostCenterController coc = new CostCenterController();
        List<CostCenterInfo> costCenter = coc.GetCostCenter();
        gdvCostCenter.DataSource = costCenter;
        gdvCostCenter.DataBind();
    }

    private void clearText()
    {
        hdfcostcenterid.Value = null;
        CostCenterName.Text = string.Empty;
        ddlDefaultPrinter.SelectedIndex = 0;
        txtCoDiscount.Text = string.Empty;
    }
    #endregion

}